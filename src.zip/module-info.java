/**
 * 
 */
/**
 * 
 */
module tnsjava {
}
package cam.AccessSpecifiers;

public class PrivateClass {
	private int a=10;
	private static int b=20;
	private void display()
	{
		System.out.println("Private method value:"+30);;
		
	}
	private static int display1()
	
	{
		return 40;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PrivateClass pc=new PrivateClass();
		System.out.println("Private non-static variable value:"+pc.a);
		System.out.println("Private static variable value:"+b);
		pc.display();
		System.out.println("Private static variable value:"+display1());
		
		

	}

}

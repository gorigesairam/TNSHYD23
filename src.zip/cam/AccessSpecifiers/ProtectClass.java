package cam.AccessSpecifiers;

public class ProtectClass {
	protected int a=10;
	protected static int b=20;
	protected void display()
	{
		System.out.println("protected non-static method value:"+30);
	}
	protected static int display1()
	{
		return 40;
	}

}

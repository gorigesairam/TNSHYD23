package protectAccessSpecifier;

import cam.AccessSpecifiers.ProtectClass;

public class Main extends ProtectClass {

    public static void main(String[] args) {
        //ProtectClass pc=new ProtectClass();
    	Main m = new Main();

        // Accessing protected non-static variable and method via inheritance
        System.out.println("Protected non-static variable value: " + m.a);
        m.display();

        // Accessing protected static variable and method via inheritance or direct class reference
        System.out.println("Protected static variable value: " + Main.b);
        System.out.println("Protected static method return value: " + Main.display1());
    }
}

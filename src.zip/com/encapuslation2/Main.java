package com.encapuslation2;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Student s=new Student();
Scanner sa=new Scanner(System.in);
System.out.print("enter the name:");
String str=sa.nextLine();
s.setName(str);
System.out.print("enter the id:");
int a=sa.nextInt();
s.setId(a);
System.out.print("enter the marks:");
int m=sa.nextInt();
s.setMarks(m);
System.out.println("student name:"+s.getName());
System.out.println("student id:"+s.getId());
System.out.println(s.getName()+"'s marks are:"+s.getMarks());
s.fail();

	}

}

package com.encapuslation2;

public class Student {
	private String name;
	private int id;

	private int marks;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getMarks() {
		return marks;
	}

	public void setMarks(int marks) {
		this.marks = marks;
	}
	public void fail()
	{
		if(marks>45 )
		{
			System.out.println("pass");
		}
		else
		{
			System.out.println("fail");
		}
	}

}

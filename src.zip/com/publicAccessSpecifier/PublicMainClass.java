package com.publicAccessSpecifier;



public class PublicMainClass {
	public static void main(String[]args)
	{
		PublicClass pc=new PublicClass();
		 System.out.println("Public non-static variable value: " + pc.a);
	        pc.display();
	        System.out.println("Public static variable value: " + PublicClass.b);
	        System.out.println("Public static method return value: " + PublicClass.display1());
	}

}

package com.publicAccessSpecifier;

public class PublicClass {

		public int a=10;
		public static int b=20;
		public void display()
		{
			System.out.println("public non-static method value:"+30);
		}
		public static int display1()
		{
			return 40;
		}

	}



package com.encapsulation;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Car c=new Car();
c.setDrivers("sitted");
c.setDoors("closed");

c.setSpeed(20);
c.setEngine("on");
System.out.println("driver is sitted:"+c.getDrivers());
System.out.println("doors are closed:"+c.getDoors());
System.out.println("speed is :"+c.getSpeed());
System.out.println("ENgine is "+c.getEngine());
c.run();
	}

}

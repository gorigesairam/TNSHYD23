package com.encapsulation;

public class Car {
	private String doors;
	private String engine;
	private String drivers;
	private int speed;
	
	
	public void setDoors(String doors) {
		this.doors = doors;
	}
	public String getDoors() {
		return doors;
	}
	
	public void setEngine(String engine) {
		this.engine = engine;
	}
	public String getEngine() {
		return engine;
	}
	 public void setDrivers(String drivers)
	 {
		 this.drivers=drivers;
	 }
	 
	 public String getDrivers()
	 {
		 return drivers;
		 
	 }
	 
	 public void setSpeed(int speed)
	 {
	 this.speed=speed;
	}
	public int getSpeed()
	 {
		 return speed;
	}
	
	public void run()
	{
		if(doors.equals("closed")&&engine.equals("on"))
		{
			System.out.println("car is running");
		}
		else
		{
			System.out.println("car is not running");
		}
	}
	
	
	

}

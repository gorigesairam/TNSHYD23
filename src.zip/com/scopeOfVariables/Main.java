package com.scopeOfVariables;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Approach2 app=new Approach2();
		int c=50;
		System.out.println("The local variable value:"+c);
		System.out.println("Non static instance variable value:"+app.a);
		app.display();
		System.out.println("Static instance variable value:"+app.display1());
		
		

	}

}

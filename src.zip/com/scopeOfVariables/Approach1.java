package com.scopeOfVariables;

public class Approach1 {
	int c=20;
	static int b=30;
	 void display()
	 {
		 System.out.println("T his void instance method value:"+40);
	 }
	 static int display1()
	 {
		 //System.out.print("this is static method value:");
		 return 50;
	 }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Approach1 ap=new Approach1();
		int a=10;
		System.out.println("Local variable value:"+a);
		System.out.println("Non static instance variable value:"+ap.c);
		System.out.println("Static instance variable value:"+b);
		ap.display();
		System.out.println("Static instance variable value:"+display1());
		
		
		

	}

}

package com.scopeOfVariables;

public class Approach2 {
int a=10;
static int b=20;
void display()
{
	System.out.println("This is void instance method value"+30);
}
static int display1() {
	
	return 40;
}
}

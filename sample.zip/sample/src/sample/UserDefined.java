package sample;

public class UserDefined {
	public static void main(String[] args)
	{
		System.out.println("user defined package");
	}

}

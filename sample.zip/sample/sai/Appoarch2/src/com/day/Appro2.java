package com.day;

public class Appro2 {
	int a=20;
	static int b=30;
	int display()
	{
		System.out.print("instance method");
		return 100;
	}
static void display1()
{
	System.out.println("static instance method:"+200);
}
}

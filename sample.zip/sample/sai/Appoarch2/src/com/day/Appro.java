 package com.day;

public class Appro {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int c =20;
System.out.println("local variable value:"+c);
Appro2 s=new Appro2();
System.out.println("instance value :"+s.a);
System.out.println("static instance value:"+Appro2.b);
System.out.println("instance method value:"+s.display());
Appro2.display1();
	}

}

package com.day1;

public class PrivateClass
{
    private static  int a=10;
    private int display()
    {
        System.out.print("instance method:");
        return 100;
    }
    public static void main(String[]args)
    {
       PrivateClass p=new PrivateClass();
        System.out.println(a);
        System.out.println(p.display());
    }

}
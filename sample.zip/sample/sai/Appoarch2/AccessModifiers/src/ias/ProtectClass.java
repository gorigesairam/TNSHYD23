package ias;
import ram.*;

public class ProtectClass extends Main {
	
		
		public static void main(String[] args)
		    {
		        ProtectClass p1 = new ProtectClass();
		        
		        System.out.println(p1.str);

		        
		        
		      
		        
		    }
		}





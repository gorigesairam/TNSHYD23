package sai;

public class Pclass2 {
	public int a=10;
	public  int display()
	{
		System.out.print("public instance method:");
		return 100;
	}

}

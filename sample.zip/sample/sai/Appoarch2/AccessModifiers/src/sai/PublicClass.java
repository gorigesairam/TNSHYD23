package sai;

public class PublicClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Pclass2 p=new Pclass2();
		System.out.println("public instance value:"+p.a);
		System.out.println(p.display());

	}

}

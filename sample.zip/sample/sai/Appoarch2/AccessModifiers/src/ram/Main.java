package ram;

public class Main {
	
		protected String str = "Hello";
	    public static void main(String[] args) {
	    	Main m1 = new Main();
	    	
	    	System.out.println(m1.str);
		}
	    
	    

	}



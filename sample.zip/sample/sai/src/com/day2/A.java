package com.day2;

public class A {
	int a=10;
	static int b=20;
	 static int display()
	{
		System.out.println("this is instacne method");
		return 100;
	}
	void display1()
	{
		System.out.println("200");
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A a1=new A();
		System.out.println(a1.a);
		System.out.println(b);
		System.out.println(display());
		a1.display1();

	}

}
